Govt Exam AI Android v2
=======================

यह browser website नहीं है। यह native Android app project है।

इसमें अभी:
- Strict Selection Instructor UI
- Offline/local Dashboard
- Daily Mission (offline fallback + AI mission)
- AI chat: Fast / Standard / Premier
- Live web research toggle
- Mock analyzer
- Permanent local mistake ledger (SQLite)
- Study image/diagram generation screen
- Student profile
- Backend/model version checker
- AI model को backend से बदलने की सुविधा, इसलिए model update के लिए हर बार APK बदलना जरूरी नहीं

SECURITY:
OpenAI API key APK के अंदर नहीं रखी गई है। यह जानबूझकर है। API key केवल backend server में होगी।

APK कैसे बनेगा:
इस execution environment में Android SDK/Gradle compiler मौजूद नहीं था, इसलिए मैं यहाँ APK binary compile नहीं कर पाया।
लेकिन android-app folder पूरा buildable Android Studio/Gradle project है और GitHub Actions workflow भी दिया गया है।
GitHub पर android-app folder repo में डालकर Actions > Build Android APK > Run workflow करने पर cloud में app-debug.apk बनेगा।

Phone में app चलाने के बाद:
1) Profile भरें
2) Settings में backend URL डालें
3) AI ONLINE दिखने पर chat/images/live research काम करेंगे
4) Backend नहीं हो तो Dashboard, mocks, mistakes और offline mission फिर भी काम करेंगे

Backend:
backend folder में server.py + requirements.txt + .env.example है।
OPENAI_API_KEY केवल उसी server के environment में रखें।

Important:
किसी AI से selection की 100% guarantee नहीं हो सकती। यह app controllable factors—accuracy, speed, PYQ practice,
revision, mock analysis और mistake correction—को aggressively optimize करने के लिए बनाया गया है।
