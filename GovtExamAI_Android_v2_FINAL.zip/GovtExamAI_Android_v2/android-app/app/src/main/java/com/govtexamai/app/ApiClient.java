package com.govtexamai.app;

import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {
    public static JSONObject post(String baseUrl, String path, JSONObject payload, String appToken) throws Exception {
        URL url = new URL(clean(baseUrl) + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(25000);
        conn.setReadTimeout(180000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        if (appToken != null && !appToken.isEmpty()) conn.setRequestProperty("X-App-Token", appToken);
        byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
        try(OutputStream os = conn.getOutputStream()) { os.write(body); }
        return readJson(conn);
    }

    public static JSONObject get(String baseUrl, String path, String appToken) throws Exception {
        URL url = new URL(clean(baseUrl) + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        if (appToken != null && !appToken.isEmpty()) conn.setRequestProperty("X-App-Token", appToken);
        return readJson(conn);
    }

    private static JSONObject readJson(HttpURLConnection conn) throws Exception {
        int status = conn.getResponseCode();
        InputStream in = status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream();
        String text = readAll(in);
        if (status < 200 || status >= 300) throw new IOException("Server " + status + ": " + text);
        return new JSONObject(text);
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        return out.toString(StandardCharsets.UTF_8.name());
    }

    private static String clean(String s) {
        s = s == null ? "" : s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length()-1);
        return s;
    }
}
