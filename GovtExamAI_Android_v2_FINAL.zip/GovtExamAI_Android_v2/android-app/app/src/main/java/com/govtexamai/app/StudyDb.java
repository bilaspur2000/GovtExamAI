package com.govtexamai.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

public class StudyDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "govt_exam_ai.db";
    private static final int DB_VERSION = 1;

    public StudyDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE mistakes (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, subject TEXT, topic TEXT, type TEXT, note TEXT, correction TEXT, status TEXT DEFAULT 'Open')");
        db.execSQL("CREATE TABLE mocks (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, name TEXT, total INTEGER, attempted INTEGER, correct INTEGER, wrong INTEGER, score REAL, accuracy REAL, minutes REAL, notes TEXT)");
        db.execSQL("CREATE TABLE missions (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, mission TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public void addMistake(String subject, String topic, String type, String note, String correction) {
        ContentValues v = new ContentValues();
        v.put("created_at", now()); v.put("subject", subject); v.put("topic", topic);
        v.put("type", type); v.put("note", note); v.put("correction", correction); v.put("status", "Open");
        getWritableDatabase().insert("mistakes", null, v);
    }

    public void closeMistake(long id) {
        ContentValues v = new ContentValues(); v.put("status", "Corrected");
        getWritableDatabase().update("mistakes", v, "id=?", new String[]{String.valueOf(id)});
    }

    public int countOpenMistakes() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM mistakes WHERE status='Open'", null);
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }

    public String firstOpenTopic() {
        Cursor c = getReadableDatabase().rawQuery("SELECT topic FROM mistakes WHERE status='Open' ORDER BY id ASC LIMIT 1", null);
        String s = c.moveToFirst() ? c.getString(0) : "weakest topic"; c.close(); return s;
    }

    public JSONArray mistakeArray(int limit) {
        JSONArray arr = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,created_at,subject,topic,type,note,correction,status FROM mistakes ORDER BY id DESC LIMIT " + limit, null);
        try {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0)); o.put("created_at", c.getString(1)); o.put("subject", c.getString(2));
                o.put("topic", c.getString(3)); o.put("type", c.getString(4)); o.put("note", c.getString(5));
                o.put("correction", c.getString(6)); o.put("status", c.getString(7)); arr.put(o);
            }
        } catch (Exception ignored) {} finally { c.close(); }
        return arr;
    }

    public void addMock(String name, int total, int attempted, int correct, int wrong, double score, double accuracy, double minutes, String notes) {
        ContentValues v = new ContentValues();
        v.put("created_at", now()); v.put("name", name); v.put("total", total); v.put("attempted", attempted);
        v.put("correct", correct); v.put("wrong", wrong); v.put("score", score); v.put("accuracy", accuracy);
        v.put("minutes", minutes); v.put("notes", notes);
        getWritableDatabase().insert("mocks", null, v);
    }

    public JSONArray mockArray(int limit) {
        JSONArray arr = new JSONArray();
        Cursor c = getReadableDatabase().rawQuery("SELECT id,created_at,name,total,attempted,correct,wrong,score,accuracy,minutes,notes FROM mocks ORDER BY id DESC LIMIT " + limit, null);
        try {
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", c.getLong(0)); o.put("created_at", c.getString(1)); o.put("name", c.getString(2));
                o.put("total", c.getInt(3)); o.put("attempted", c.getInt(4)); o.put("correct", c.getInt(5));
                o.put("wrong", c.getInt(6)); o.put("score", c.getDouble(7)); o.put("accuracy", c.getDouble(8));
                o.put("minutes", c.getDouble(9)); o.put("notes", c.getString(10)); arr.put(o);
            }
        } catch (Exception ignored) {} finally { c.close(); }
        return arr;
    }

    public double latestAccuracy() {
        Cursor c = getReadableDatabase().rawQuery("SELECT accuracy FROM mocks ORDER BY id DESC LIMIT 1", null);
        double x = c.moveToFirst() ? c.getDouble(0) : -1; c.close(); return x;
    }

    public double averageAccuracy() {
        Cursor c = getReadableDatabase().rawQuery("SELECT AVG(accuracy) FROM (SELECT accuracy FROM mocks ORDER BY id DESC LIMIT 10)", null);
        double x = (c.moveToFirst() && !c.isNull(0)) ? c.getDouble(0) : -1; c.close(); return x;
    }

    public void saveMission(String mission) {
        ContentValues v = new ContentValues(); v.put("created_at", now()); v.put("mission", mission);
        getWritableDatabase().insert("missions", null, v);
    }

    public String lastMission() {
        Cursor c = getReadableDatabase().rawQuery("SELECT mission FROM missions ORDER BY id DESC LIMIT 1", null);
        String s = c.moveToFirst() ? c.getString(0) : ""; c.close(); return s;
    }

    public String performanceSummary() {
        JSONArray a = mockArray(8);
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<a.length();i++) {
            try {
                JSONObject m = a.getJSONObject(i);
                sb.append(m.optString("created_at")).append(" | ").append(m.optString("name"))
                  .append(" | score ").append(String.format("%.2f", m.optDouble("score")))
                  .append(" | accuracy ").append(String.format("%.1f%%", m.optDouble("accuracy")))
                  .append(" | ").append(String.format("%.0f min", m.optDouble("minutes"))).append("\n");
            } catch (Exception ignored) {}
        }
        return sb.length()==0 ? "No mocks recorded yet." : sb.toString();
    }

    public String mistakeSummary() {
        JSONArray a = mistakeArray(20);
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<a.length();i++) {
            try {
                JSONObject m = a.getJSONObject(i);
                if (!"Open".equals(m.optString("status"))) continue;
                sb.append(m.optString("subject")).append(" / ").append(m.optString("topic"))
                  .append(" / ").append(m.optString("type")).append(": ").append(m.optString("note")).append("\n");
            } catch (Exception ignored) {}
        }
        return sb.length()==0 ? "No open mistakes." : sb.toString();
    }

    private static String now() {
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(new java.util.Date());
    }
}
