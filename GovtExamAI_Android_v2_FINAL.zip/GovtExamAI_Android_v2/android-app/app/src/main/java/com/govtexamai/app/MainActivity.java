package com.govtexamai.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.text.util.Linkify;
import android.text.method.LinkMovementMethod;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private StudyDb db;
    private SharedPreferences prefs;
    private LinearLayout content;
    private TextView connectionBadge;

    private static final int NAVY = Color.rgb(15,23,42);
    private static final int BLUE = Color.rgb(37,99,235);
    private static final int GREEN = Color.rgb(22,163,74);
    private static final int RED = Color.rgb(220,38,38);
    private static final int BG = Color.rgb(248,250,252);
    private static final int MUTED = Color.rgb(71,85,105);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new StudyDb(this);
        prefs = getSharedPreferences("govt_exam_ai", MODE_PRIVATE);
        buildShell();
        showHome();
        checkServer(false);
        if (!prefs.getBoolean("profile_done", false)) showProfileDialog();
    }

    @Override protected void onDestroy() { super.onDestroy(); io.shutdownNow(); }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("🎯 Govt Exam AI", 23, NAVY, true); header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        connectionBadge = text("OFFLINE", 12, RED, true); header.addView(connectionBadge);
        root.addView(header);
        root.addView(text("Strict Selection Instructor • Browser-free study app", 13, MUTED, false));

        HorizontalScrollView navScroll = new HorizontalScrollView(this); navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setPadding(0, dp(10), 0, dp(8));
        addNav(nav,"Home",v->showHome()); addNav(nav,"Mission",v->showMission()); addNav(nav,"AI",v->showChat());
        addNav(nav,"Mock",v->showMock()); addNav(nav,"Mistakes",v->showMistakes()); addNav(nav,"Images",v->showImages()); addNav(nav,"Settings",v->showSettings());
        navScroll.addView(nav); root.addView(navScroll);

        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(2), 0, dp(30)); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        setContentView(root);
    }

    private void addNav(LinearLayout nav, String name, View.OnClickListener click) {
        Button b = new Button(this); b.setText(name); b.setTextSize(12); b.setAllCaps(false); b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)); p.setMargins(0,0,dp(6),0); nav.addView(b,p);
    }

    private void clear(String heading, String sub) {
        content.removeAllViews(); content.addView(text(heading,21,NAVY,true));
        if (sub != null && !sub.isEmpty()) { TextView s=text(sub,13,MUTED,false); s.setPadding(0,dp(3),0,dp(12)); content.addView(s); }
    }

    private void showHome() {
        clear("Readiness Dashboard", "Evidence first: accuracy, speed, revision, mistakes, consistency.");
        String exam = prefs.getString("exam","SSC CGL");
        content.addView(card("Target exam", exam));
        double la = db.latestAccuracy(), aa = db.averageAccuracy();
        content.addView(card("Latest mock accuracy", la < 0 ? "No mock yet" : String.format("%.1f%%",la)));
        content.addView(card("10-mock average", aa < 0 ? "No history yet" : String.format("%.1f%%",aa)));
        content.addView(card("Open mistakes", String.valueOf(db.countOpenMistakes())));
        TextView note = text("Selection cannot be guaranteed by any AI. The app is built to maximize controllable factors and remove repeatable weaknesses.",13,RED,true);
        note.setPadding(dp(12),dp(14),dp(12),dp(14)); content.addView(note);
        Button mission = primary("Generate today's mission"); mission.setOnClickListener(v->showMission()); content.addView(mission);
    }

    private void showMission() {
        clear("Today's Mission", "No vague 'study 6 hours'. Targets must be measurable.");
        TextView out = text(db.lastMission().isEmpty() ? offlineMission() : db.lastMission(),15,NAVY,false);
        out.setTextIsSelectable(true); out.setPadding(dp(12),dp(12),dp(12),dp(16)); content.addView(out);
        Button gen = primary("Generate strict mission"); content.addView(gen);
        gen.setOnClickListener(v->{
            gen.setEnabled(false); out.setText("Generating mission…");
            JSONObject payload = commonPayload();
            runPost("/v1/mission",payload,(j)->{
                String answer=j.optString("answer",offlineMission()); db.saveMission(answer); out.setText(answer); gen.setEnabled(true);
            },(e)->{ out.setText(offlineMission()+"\n\nServer unavailable: "+e); gen.setEnabled(true); });
        });
    }

    private void showChat() {
        clear("Strict AI Instructor", "Ask concepts, PYQs, drills, strategy or current exam information.");
        Spinner mode = spinner(new String[]{"Standard","Premier","Fast"}); content.addView(label("AI mode")); content.addView(mode);
        CheckBox live = new CheckBox(this); live.setText("Live web research for current information"); live.setChecked(true); content.addView(live);
        EditText input = edit("Example: Percentage is weak. Test me with 10 SSC-level questions.",true); content.addView(input);
        Button send=primary("Send to instructor"); content.addView(send);
        TextView out=text("",15,NAVY,false); out.setTextIsSelectable(true); out.setAutoLinkMask(Linkify.WEB_URLS); out.setMovementMethod(LinkMovementMethod.getInstance()); out.setPadding(dp(8),dp(14),dp(8),dp(20)); content.addView(out);
        send.setOnClickListener(v->{
            String q=input.getText().toString().trim(); if(q.isEmpty()){toast("Write a question first.");return;}
            send.setEnabled(false); out.setText("Instructor is analysing…");
            JSONObject p=commonPayload(); try{p.put("message",q);p.put("mode",mode.getSelectedItem().toString().toLowerCase());p.put("live_web",live.isChecked());}catch(Exception ignored){}
            runPost("/v1/chat",p,(j)->{ out.setText(j.optString("answer","No answer.")); Linkify.addLinks(out,Linkify.WEB_URLS); send.setEnabled(true); },(e)->{out.setText("AI backend unavailable.\n\n"+e);send.setEnabled(true);});
        });
    }

    private void showMock() {
        clear("Mock Analyzer", "Every wrong answer must become a fix, not just a score.");
        EditText name=edit("Mock name",false); name.setText("Full Mock");
        EditText total=num("Total questions","100"); EditText attempted=num("Attempted","80"); EditText correct=num("Correct","60"); EditText wrong=num("Wrong","20");
        EditText marks=decimal("Marks per correct","1"); EditText neg=decimal("Negative per wrong","0.25"); EditText mins=decimal("Time in minutes","60"); EditText notes=edit("Weak sections / notes",true);
        for(View v:new View[]{name,total,attempted,correct,wrong,marks,neg,mins,notes}) content.addView(v);
        Button save=primary("Save & analyse"); content.addView(save); TextView out=text("",14,NAVY,false); out.setPadding(0,dp(12),0,0); content.addView(out);
        save.setOnClickListener(v->{
            try {
                int t=i(total),a=i(attempted),c=i(correct),w=i(wrong); double m=d(marks),n=d(neg),min=d(mins);
                if(c+w>a || a>t){toast("Check counts: Correct + Wrong ≤ Attempted ≤ Total");return;}
                double score=c*m-w*n, acc=a==0?0:(100.0*c/a);
                db.addMock(name.getText().toString(),t,a,c,w,score,acc,min,notes.getText().toString());
                out.setText(String.format("Saved. Score %.2f | Accuracy %.1f%%\n\nGenerating highest-return fixes…",score,acc));
                JSONObject p=commonPayload(); p.put("message",String.format("Analyse this mock strictly: total=%d attempted=%d correct=%d wrong=%d score=%.2f accuracy=%.1f%% time=%.1f min notes=%s. Give top 3 fixes and measurable retest condition.",t,a,c,w,score,acc,min,notes.getText())); p.put("mode","standard"); p.put("live_web",false);
                runPost("/v1/chat",p,(j)->out.setText(String.format("Score %.2f | Accuracy %.1f%%\n\n%s",score,acc,j.optString("answer"))),(e)->out.setText(String.format("Score %.2f | Accuracy %.1f%%\nSaved locally. AI analysis unavailable: %s",score,acc,e)));
            } catch(Exception ex){toast("Enter valid numbers.");}
        });
    }

    private void showMistakes() {
        clear("Mistake Ledger", "A repeated mistake is a system failure. Log it, correct it, retest it.");
        String[] subjects={"Quant/Maths","Reasoning","English","Hindi","GK/GS","Current Affairs","Computer","Other"};
        String[] types={"Concept weakness","Calculation/execution error","Memory failure","Misread question","Time pressure","Guessing","Poor revision","Strategy error"};
        Spinner subject=spinner(subjects), type=spinner(types); EditText topic=edit("Topic (e.g. Percentage)",false); EditText note=edit("What went wrong / question",true); EditText correction=edit("Correct method / lesson",true);
        content.addView(label("Subject"));content.addView(subject);content.addView(topic);content.addView(label("Mistake type"));content.addView(type);content.addView(note);content.addView(correction);
        Button add=primary("Add mistake"); content.addView(add); add.setOnClickListener(v->{ if(topic.getText().toString().trim().isEmpty()||note.getText().toString().trim().isEmpty()){toast("Topic and mistake note required.");return;} db.addMistake(subject.getSelectedItem().toString(),topic.getText().toString().trim(),type.getSelectedItem().toString(),note.getText().toString().trim(),correction.getText().toString().trim()); toast("Mistake saved."); showMistakes(); });
        JSONArray arr=db.mistakeArray(30);
        for(int x=0;x<arr.length();x++) try{
            JSONObject m=arr.getJSONObject(x); LinearLayout box=box();
            box.addView(text(("Open".equals(m.optString("status"))?"❌ ":"✅ ")+m.optString("subject")+" — "+m.optString("topic"),15,NAVY,true));
            box.addView(text(m.optString("type")+"\n"+m.optString("note"),13,MUTED,false));
            if(!m.optString("correction").isEmpty()) box.addView(text("Correction: "+m.optString("correction"),13,GREEN,false));
            if("Open".equals(m.optString("status"))){ Button done=new Button(this);done.setText("Mark corrected");done.setAllCaps(false);long id=m.optLong("id");done.setOnClickListener(v->{db.closeMistake(id);showMistakes();});box.addView(done); }
            content.addView(box);
        }catch(Exception ignored){}
    }

    private void showImages() {
        clear("Study Images & Diagrams", "Generate maps, science diagrams, reasoning figures, visual memory aids and concept illustrations inside the app.");
        EditText prompt=edit("Example: Make a clean labelled diagram explaining human heart blood circulation for competitive-exam revision.",true); content.addView(prompt);
        Button gen=primary("Generate study image"); content.addView(gen);
        ProgressBar progress=new ProgressBar(this); progress.setVisibility(View.GONE); content.addView(progress);
        ImageView img=new ImageView(this); img.setAdjustViewBounds(true); img.setScaleType(ImageView.ScaleType.FIT_CENTER); content.addView(img,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView status=text("",13,MUTED,false);content.addView(status);
        gen.setOnClickListener(v->{String ptxt=prompt.getText().toString().trim();if(ptxt.isEmpty()){toast("Describe the image you need.");return;}gen.setEnabled(false);progress.setVisibility(View.VISIBLE);status.setText("Generating educational image…");JSONObject p=commonPayload();try{p.put("prompt",ptxt);}catch(Exception ignored){}runPost("/v1/image",p,(j)->{try{String b64=j.optString("image_base64");byte[] bytes=Base64.decode(b64,Base64.DEFAULT);Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);img.setImageBitmap(bmp);status.setText(j.optString("note","Generated."));}catch(Exception e){status.setText("Could not decode image: "+e);}progress.setVisibility(View.GONE);gen.setEnabled(true);},(e)->{status.setText("Image backend unavailable: "+e);progress.setVisibility(View.GONE);gen.setEnabled(true);});});
    }

    private void showSettings() {
        clear("Settings", "Backend changes can upgrade the AI model without reinstalling the app.");
        EditText server=edit("Backend URL",false);server.setText(prefs.getString("server_url",""));content.addView(label("Secure backend URL (HTTPS recommended)"));content.addView(server);
        EditText token=edit("Optional app token",false);token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);token.setText(prefs.getString("app_token",""));content.addView(token);
        Button save=primary("Save connection");content.addView(save);save.setOnClickListener(v->{prefs.edit().putString("server_url",server.getText().toString().trim()).putString("app_token",token.getText().toString().trim()).apply();toast("Saved.");checkServer(true);});
        Button profile=new Button(this);profile.setText("Edit student profile");profile.setAllCaps(false);profile.setOnClickListener(v->showProfileDialog());content.addView(profile);
        Button check=new Button(this);check.setText("Check AI/version");check.setAllCaps(false);content.addView(check);
        TextView info=text("",13,MUTED,false);content.addView(info);check.setOnClickListener(v->{info.setText("Checking…");checkServer(true);String s=prefs.getString("server_url","");if(s.isEmpty()){info.setText("No backend URL configured.");return;}io.execute(()->{try{JSONObject j=ApiClient.get(s,"/v1/version",prefs.getString("app_token",""));runOnUiThread(()->info.setText("App: 2.0.0\nAI: "+j.optString("premier_model")+"\nStandard: "+j.optString("standard_model")+"\nFast: "+j.optString("fast_model")+"\nImages: "+j.optString("image_model")+"\nLatest app: "+j.optString("latest_app_version","2.0.0")));}catch(Exception e){runOnUiThread(()->info.setText("Cannot reach backend: "+e.getMessage()));}});});
        TextView security=text("Security: the OpenAI API key is never stored in this APK. Keep it only on your backend server.",13,RED,true);security.setPadding(0,dp(16),0,0);content.addView(security);
    }

    private void showProfileDialog() {
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(8),dp(20),0);
        EditText name=edit("Your name",false);name.setText(prefs.getString("name",""));
        Spinner exam=spinner(new String[]{"SSC CGL","SSC CHSL","SSC CPO","SSC MTS","RRB NTPC","RRB Group D","IBPS PO","IBPS Clerk","SBI PO","State Police","State PSC","UPSC CSE","CTET/TET","CDS","AFCAT","Other Govt Exam"});
        String oldExam=prefs.getString("exam","SSC CGL");for(int i=0;i<exam.getCount();i++)if(exam.getItemAtPosition(i).toString().equals(oldExam))exam.setSelection(i);
        EditText date=edit("Exam date / expected month",false);date.setText(prefs.getString("exam_date",""));
        EditText hours=decimal("Daily study hours","4");hours.setText(String.valueOf(prefs.getFloat("hours",4f)));
        Spinner lang=spinner(new String[]{"Hinglish","Hindi","English"});
        Spinner level=spinner(new String[]{"Beginner","Intermediate","Advanced"});
        l.addView(name);l.addView(label("Target exam"));l.addView(exam);l.addView(date);l.addView(hours);l.addView(label("Instructor language"));l.addView(lang);l.addView(label("Current level"));l.addView(level);
        new AlertDialog.Builder(this).setTitle("Student Profile").setView(l).setCancelable(false).setPositiveButton("Save",(d,w)->{float h=4f;try{h=Float.parseFloat(hours.getText().toString());}catch(Exception ignored){}prefs.edit().putBoolean("profile_done",true).putString("name",name.getText().toString()).putString("exam",exam.getSelectedItem().toString()).putString("exam_date",date.getText().toString()).putFloat("hours",h).putString("language",lang.getSelectedItem().toString()).putString("level",level.getSelectedItem().toString()).apply();showHome();}).show();
    }

    private JSONObject commonPayload() {
        JSONObject p=new JSONObject();try{
            p.put("name",prefs.getString("name","Student"));p.put("exam",prefs.getString("exam","SSC CGL"));p.put("exam_date",prefs.getString("exam_date",""));p.put("daily_hours",prefs.getFloat("hours",4f));p.put("language",prefs.getString("language","Hinglish"));p.put("level",prefs.getString("level","Beginner"));p.put("performance",db.performanceSummary());p.put("mistakes",db.mistakeSummary());
        }catch(Exception ignored){}return p;
    }

    private String offlineMission() {
        int q=Math.max(40,(int)(prefs.getFloat("hours",4f)*18));String weak=db.firstOpenTopic();String exam=prefs.getString("exam","your exam");
        return "TODAY'S NON-NEGOTIABLE MISSION\n1. "+weak+": concept revision + "+Math.max(20,q/3)+" timed questions.\n2. "+exam+" mixed PYQ drill: "+Math.max(25,q/2)+" questions. Log every error.\n3. Re-attempt every open mistake due for revision.\n4. Finish with a timed sectional test.\n\nSuccess condition: ≥85% practice accuracy and every wrong answer classified by cause.\nIf unfinished: carry forward only the highest-priority unfinished work; do not create unsafe catch-up hours.";
    }

    private interface Ok { void run(JSONObject j); } private interface Fail { void run(String error); }
    private void runPost(String path, JSONObject p, Ok ok, Fail fail) {
        String s=prefs.getString("server_url",""); if(s.isEmpty()){fail.run("No backend configured. Open Settings and add your backend URL.");return;}
        io.execute(()->{try{JSONObject j=ApiClient.post(s,path,p,prefs.getString("app_token",""));runOnUiThread(()->ok.run(j));}catch(Exception e){runOnUiThread(()->fail.run(e.getMessage()));}});
    }

    private void checkServer(boolean toastResult) {
        String s=prefs.getString("server_url","");if(s.isEmpty()){connectionBadge.setText("LOCAL");connectionBadge.setTextColor(MUTED);return;}
        io.execute(()->{try{ApiClient.get(s,"/health",prefs.getString("app_token",""));runOnUiThread(()->{connectionBadge.setText("AI ONLINE");connectionBadge.setTextColor(GREEN);if(toastResult)toast("AI backend connected.");});}catch(Exception e){runOnUiThread(()->{connectionBadge.setText("LOCAL");connectionBadge.setTextColor(RED);if(toastResult)toast("Backend not reachable.");});}});
    }

    private LinearLayout card(String k,String v){LinearLayout box=box();box.addView(text(k,13,MUTED,false));box.addView(text(v,20,NAVY,true));return box;}
    private LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(14),dp(12),dp(14),dp(12));b.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,0,0,dp(8));b.setLayoutParams(p);return b;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);t.setLineSpacing(0,1.15f);return t;}
    private TextView label(String s){TextView t=text(s,12,MUTED,true);t.setPadding(0,dp(10),0,dp(3));return t;}
    private Button primary(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundColor(BLUE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(52));p.setMargins(0,dp(8),0,dp(6));b.setLayoutParams(p);return b;}
    private EditText edit(String hint,boolean multi){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setPadding(dp(10),dp(10),dp(10),dp(10));if(multi){e.setMinLines(3);e.setGravity(Gravity.TOP);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);}else e.setSingleLine(true);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,dp(5),0,dp(5));e.setLayoutParams(p);return e;}
    private EditText num(String hint,String val){EditText e=edit(hint,false);e.setInputType(InputType.TYPE_CLASS_NUMBER);e.setText(val);return e;}
    private EditText decimal(String hint,String val){EditText e=edit(hint,false);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setText(val);return e;}
    private Spinner spinner(String[] items){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items));s.setPadding(0,dp(4),0,dp(4));return s;}
    private int i(EditText e){return Integer.parseInt(e.getText().toString().trim());} private double d(EditText e){return Double.parseDouble(e.getText().toString().trim());}
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
