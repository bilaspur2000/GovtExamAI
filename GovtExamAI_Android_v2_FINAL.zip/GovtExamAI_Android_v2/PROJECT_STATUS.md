# Govt Exam AI v2 — project status

## Implemented
- Native Android (Java, no WebView)
- Local SQLite mocks and mistakes
- Student profile
- Dashboard
- Strict daily mission with offline fallback
- AI chat with Fast / Standard / Premier routing
- Optional live web research
- Study image generation
- Backend health + model/version check
- Secure architecture: no OpenAI key in APK
- GitHub Actions APK build workflow

## Default model routing (server-side, editable)
- Premier: `gpt-6-astra`
- Standard: `gpt-6-sol`
- Fast: `gpt-6-luna`
- Study images: `gpt-image-2.5-flare`

## Next engineering milestones
- PYQ database/importer with year/topic/difficulty tags
- Spaced repetition scheduler (1/3/7/15/30-day)
- Camera/photo question input and vision solving
- Timed sectional/full mock engine with individual questions
- Cloud account/sync and backup
- Push reminders / scheduled daily mission
- Signed release APK and in-app release download
- Official notification ingestion / exam-specific syllabus packs
