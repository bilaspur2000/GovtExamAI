import os, base64
from typing import Optional, Literal
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
app = FastAPI(title="Govt Exam AI Backend", version="2.0.0")

PREMIER = os.getenv("PREMIER_MODEL", "gpt-6-astra")
STANDARD = os.getenv("STANDARD_MODEL", "gpt-6-sol")
FAST = os.getenv("FAST_MODEL", "gpt-6-luna")
IMAGE = os.getenv("IMAGE_MODEL", "gpt-image-2.5-flare")
APP_TOKEN = os.getenv("APP_TOKEN", "").strip()
LATEST_APP_VERSION = os.getenv("LATEST_APP_VERSION", "2.0.0")

def get_client():
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY is not configured on the backend")
    return OpenAI(api_key=key)

STRICT_PROMPT = """
You are Selection Instructor, a strict evidence-driven instructor for Indian government examinations.
Your objective is to maximize the student's measurable exam readiness. Never promise or imply guaranteed selection.
Be firm, concise, demanding and practical, but never insult, humiliate, threaten, manipulate, encourage sleep deprivation,
unsafe workloads, cheating, leaked papers, bribery, impersonation, or illegal/unethical shortcuts.

Always optimize this loop: syllabus -> concept -> PYQ -> timed practice -> mock -> error diagnosis -> retest -> spaced revision.
Judge progress using measurable evidence: accuracy, speed, syllabus coverage, revision retention, PYQ performance,
mock performance and consistency. Do not give empty praise. Praise only measurable improvement.
Classify errors as: concept weakness, calculation/execution error, memory failure, misread question, time pressure,
guessing, poor revision, or strategy error. Repeated mistakes must return in later practice.
Prefer output targets over vague study-hour targets.

For any current notification, date, vacancy, eligibility rule, exam pattern, current affairs or changing fact, use web search
when available. Prefer official recruitment boards, commissions, ministries, departments, PIB and primary documents.
Clearly distinguish confirmed official facts from estimates or coaching claims. Never invent notifications, cutoffs or dates.
When web research is used, include clickable source URLs/citations.

Match the student's language: Hindi, Hinglish or English.
""".strip()

class BaseContext(BaseModel):
    name: str = "Student"
    exam: str = "Govt Exam"
    exam_date: str = ""
    daily_hours: float = 4
    language: str = "Hinglish"
    level: str = "Beginner"
    performance: str = "No mocks recorded yet."
    mistakes: str = "No open mistakes."

class ChatRequest(BaseContext):
    message: str
    mode: Literal["fast", "standard", "premier"] = "standard"
    live_web: bool = True

class ImageRequest(BaseContext):
    prompt: str

class MissionRequest(BaseContext):
    pass

def auth(x_app_token: Optional[str]):
    if APP_TOKEN and x_app_token != APP_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid app token")

def ctx(r: BaseContext) -> str:
    return f"""STUDENT
Name: {r.name}
Target exam: {r.exam}
Exam date/horizon: {r.exam_date or 'Not set'}
Daily study time: {r.daily_hours} hours
Level: {r.level}
Preferred language: {r.language}

RECENT PERFORMANCE
{r.performance}

OPEN MISTAKES
{r.mistakes}
"""

def extract_sources(response):
    try:
        data = response.model_dump()
    except Exception:
        return []
    found, seen = [], set()
    def walk(x):
        if isinstance(x, dict):
            if x.get("type") == "url_citation":
                url = x.get("url") or (x.get("url_citation") or {}).get("url")
                title = x.get("title") or (x.get("url_citation") or {}).get("title") or url
                if url and url not in seen:
                    seen.add(url); found.append({"title": title, "url": url})
            for v in x.values(): walk(v)
        elif isinstance(x, list):
            for v in x: walk(v)
    walk(data)
    return found[:12]

def format_answer(response):
    text = response.output_text or ""
    sources = extract_sources(response)
    if sources:
        text += "\n\nSources:\n" + "\n".join(f"- {s['title']}: {s['url']}" for s in sources)
    return text

def model_for(mode: str):
    return {"fast": FAST, "standard": STANDARD, "premier": PREMIER}.get(mode, STANDARD)

def reasoning_for(mode: str):
    return {"fast": "low", "standard": "medium", "premier": "high"}.get(mode, "medium")

@app.get("/health")
def health(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    return {"ok": True}

@app.get("/v1/version")
def version(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    return {
        "backend_version": "2.0.0",
        "latest_app_version": LATEST_APP_VERSION,
        "premier_model": PREMIER,
        "standard_model": STANDARD,
        "fast_model": FAST,
        "image_model": IMAGE,
        "model_updates_without_apk": True,
    }

@app.post("/v1/chat")
def chat(r: ChatRequest, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    tools = [{"type": "web_search"}] if r.live_web else []
    kwargs = dict(
        model=model_for(r.mode),
        reasoning={"effort": reasoning_for(r.mode)},
        instructions=STRICT_PROMPT + "\n\n" + ctx(r),
        input=r.message,
        store=False,
    )
    if tools:
        kwargs["tools"] = tools
        kwargs["include"] = ["web_search_call.action.sources"]
    response = get_client().responses.create(**kwargs)
    return {"answer": format_answer(response), "model": model_for(r.mode)}

@app.post("/v1/mission")
def mission(r: MissionRequest, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    prompt = """Create today's non-negotiable mission. It must fit the available study time and target the highest-return weaknesses.
Use measurable question counts, accuracy thresholds, timed drills, revision and a retest condition.
Format exactly with heading TODAY'S NON-NEGOTIABLE MISSION, numbered tasks, Success condition, and If unfinished.
Do not browse unless current official exam information is necessary."""
    response = get_client().responses.create(
        model=STANDARD,
        reasoning={"effort": "medium"},
        instructions=STRICT_PROMPT + "\n\n" + ctx(r),
        input=prompt,
        store=False,
    )
    return {"answer": response.output_text, "model": STANDARD}

@app.post("/v1/image")
def image(r: ImageRequest, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    safe_prompt = f"""Create an accurate educational study image for an Indian government-exam learner.
Purpose: revision and concept understanding, not decoration.
Use a clean textbook/infographic style, strong visual hierarchy, large legible labels only when useful,
no watermark, no unrelated logos, and avoid unnecessary text. If the request involves a factual diagram,
prioritize factual relationships over artistic flourish.
Student request: {r.prompt}
"""
    result = get_client().images.generate(
        model=IMAGE,
        prompt=safe_prompt,
        size="1024x1024",
        quality="medium",
    )
    b64 = result.data[0].b64_json
    return {"image_base64": b64, "mime": "image/png", "model": IMAGE, "note": "Generated inside Govt Exam AI for study use."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="0.0.0.0", port=int(os.getenv("PORT", "8000")), reload=False)
