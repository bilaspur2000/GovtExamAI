# Secure backend

The Android APK must NOT contain your OpenAI API key. Run this backend on a private/cloud server and set the app's Settings > Backend URL to its HTTPS address.

## Start locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env
python server.py
```

Health check: `GET /health`

### Model updates
Change `PREMIER_MODEL`, `STANDARD_MODEL`, `FAST_MODEL`, or `IMAGE_MODEL` in the server environment and restart the backend. The installed Android app will use the new models without a new APK.

### Production
Use HTTPS and a proper host (Render, Railway, Fly.io, a VPS, etc.). Keep `OPENAI_API_KEY` only in server-side secrets/environment variables.
